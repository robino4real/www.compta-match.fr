-- Add authorName to articles
ALTER TABLE "Article" ADD COLUMN "authorName" TEXT;
