import express from 'express';
import { env } from './config/env';
import healthRoutes from './routes/healthRoutes';
import adminRoutes from './routes/adminRoutes';
import { attachUserToRequest, requireAdmin, requireAuth } from './middleware/authMiddleware';
import { errorHandler } from './middleware/errorHandler';
import orderRoutes from './routes/orderRoutes';
import paymentRoutes from './routes/paymentRoutes';
import downloadRoutes from './routes/downloadRoutes';
import cartRoutes from './routes/cartRoutes';
import invoiceRoutes from './routes/invoiceRoutes';
import legalPageRoutes from './routes/legalPageRoutes';
import articleRoutes from './routes/articleRoutes';
import authRoutes from './routes/authRoutes';
import analyticsRoutes from './routes/analyticsRoutes';
import publicRoutes from './routes/publicRoutes';
import catalogRoutes from './routes/catalogRoutes';
import { ensureAdminAccount } from './services/adminAccountService';
import { robotsTxtHandler, sitemapHandler } from './controllers/seoController';
import path from "path";

const app = express();

app.use(express.json());

app.use('/api', healthRoutes);
app.use('/auth', authRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/public', publicRoutes);
app.use('/admin', attachUserToRequest, requireAdmin, adminRoutes);
app.use('/orders', attachUserToRequest, requireAuth, orderRoutes);
app.use('/payments', paymentRoutes);
app.use('/downloads', downloadRoutes);
app.use('/catalog', catalogRoutes);
app.use('/cart', cartRoutes);
app.use('/invoices', attachUserToRequest, requireAuth, invoiceRoutes);
app.use('/legal-pages', legalPageRoutes);
app.use('/articles', articleRoutes);
app.get('/robots.txt', robotsTxtHandler);
app.get('/sitemap.xml', sitemapHandler);
app.use(errorHandler);

ensureAdminAccount().catch((error) => {
  console.error('[admin] Impossible de vérifier/créer le compte administrateur', error);
});

// 🔹 1) Dossier du front buildé
const frontendDir = path.join(__dirname, "..", "frontend");

// 🔹 2) Servir les fichiers statiques du front
app.use(express.static(frontendDir));

// 🔹 3) Fallback SPA : toutes les routes non-API renvoient index.html
app.get("*", (req, res) => {
  // on laisse passer les routes API
  if (req.path.startsWith("/api")) {
    return res.status(404).send("Not found");
  }
  res.sendFile(path.join(frontendDir, "index.html"));
});


app.listen(env.port, () => {
  console.log(`Serveur ComptaMatch démarré sur le port ${env.port}`);
});
